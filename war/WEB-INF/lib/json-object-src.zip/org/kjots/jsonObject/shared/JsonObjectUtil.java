/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.shared;

import com.google.inject.Inject;

/**
 * JSON Object Utility.
 * <p>
 * Created: 13th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.2
 * @deprecated Use {@link JsonObjectFactory}
 */
@Deprecated
public abstract class JsonObjectUtil {
  /** The JSON object utility. */
  @Inject
  private static JsonObjectUtil jsonObjectUtil;
  
  /**
   * Retrieve the JSON object utility;
   *
   * @return The JSON object utility;
   */
  public static JsonObjectUtil get() {
    return jsonObjectUtil;
  }
  
  /**
   * Create a new JSON object.
   *
   * @param <T> The type of the JSON object.
   * @param jsonObjectClass The class of the JSON object.
   * @return The JSON object.
   * @deprecated Use {@link JsonObjectFactory#createJsonObject(Class)}
   */
  @Deprecated
  public abstract <T extends JsonObject> T createJsonObject(Class<T> jsonObjectClass);
  
  /**
   * Create a new JSON array.
   *
   * @param <T> The type of the JSON array.
   * @param jsonArrayClass The class of the JSON array.
   * @return The JSON array.
   * @deprecated Use {@link JsonObjectFactory#createJsonArray(Class)}
   */
  @Deprecated
  public abstract <T extends JsonArray> T createJsonArray(Class<T> jsonArrayClass);
}
