/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.shared.io;

import java.util.LinkedHashSet;
import java.util.Set;

import org.kjots.jsonObject.shared.JsonArray;
import org.kjots.jsonObject.shared.JsonObject;
import org.kjots.jsonObject.shared.JsonStringArray;

/**
 * JSON Generator.
 * <p>
 * Created: 18th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.3
 */
public abstract class JsonGenerator {
  /**
   * JSON Context.
   */
  private abstract class JsonContext {
    /** The parent JSON context. */
    private final JsonContext parentJsonContext;

    /**
     * Retrieve the parent JSON context.
     *
     * @return The parent JSON context.
     */
    public JsonContext getParentJsonContext() {
      return this.parentJsonContext;
    }
    
    /**
     * Retrieve the nesting level.
     *
     * @return The nesting level.
     */
    public int getNestingLevel() {
      return this.parentJsonContext.getNestingLevel() + 1;
    }
    
    /**
     * Determine if the context is set to the first element.
     *
     * @return <code> if the context is set to the first element.
     */
    public abstract boolean isFirstElement();
    
    /**
     * Advance to the next element.
     */
    public abstract void nextElement();
    
    /**
     * Construct a new JSON Context.
     */
    protected JsonContext() {
      this.parentJsonContext = JsonGenerator.this.jsonContext;
    }
  }
  
  /**
   * Root JSON Context.
   */
  private class RootJsonContext extends JsonContext {
    /** The JSONP flag. */
    private final boolean jsonp;
    
    /** The has element flag. */
    private boolean hasElement;
    
    /**
     * Construct a new Root JSON Context.
     *
     * @param jsonp The JSONP flag.
     */
    public RootJsonContext(boolean jsonp) {
      this.jsonp = jsonp;
    }
    
    /**
     * Retrieve the JSONP flag.
     *
     * @return The JSONP flag.
     */
    public boolean isJsonp() {
      return this.jsonp;
    }

    /**
     * Retrieve the nesting level.
     *
     * @return The nesting level.
     */
    @Override
    public int getNestingLevel() {
      return 0;
    }

    /**
     * Determine if the context is set to the first element.
     *
     * @return <code> if the context is set to the first element.
     */
    @Override
    public boolean isFirstElement() {
      return !this.hasElement;
    }
    
    /**
     * Advance to the next element.
     */
    @Override
    public void nextElement() {
      if (this.hasElement) {
        throw new UnsupportedOperationException("Root context cannot contain more then one element");
      }
      
      this.hasElement = true;
    }
  }
  
  /**
   * Array JSON Context.
   */
  private class ArrayJsonContext extends JsonContext {
    /** The inline flag. */
    private final boolean inline;
    
    /** The element index. */
    private int elementIndex;
    
    /**
     * Construct a new Array JSON Context.
     *
     * @param inline The inline flag.
     */
    public ArrayJsonContext(boolean inline) {
      this.inline = inline;
    }

    /**
     * Retrieve the inline flag.
     *
     * @return The inline flag.
     */
    public boolean isInline() {
      return this.inline;
    }

    /**
     * Determine if the context is set to the first element.
     *
     * @return <code> if the context is set to the first element.
     */
    @Override
    public boolean isFirstElement() {
      return this.elementIndex == 0;
    }
    
    /**
     * Advance to the next element.
     */
    @Override
    public void nextElement() {
      this.elementIndex++;
    }
  }
  
  /**
   * Object JSON Context.
   */
  private class ObjectJsonContext extends JsonContext {
    /** The key. */
    private String key;
    
    /** The keys. */
    private Set<String> keys = new LinkedHashSet<String>();
    
    /**
     * Determine if the context is set to the first element.
     *
     * @return <code> if the context is set to the first element.
     */
    @Override
    public boolean isFirstElement() {
      return this.keys.isEmpty();
    }
    
    /**
     * Advance to the next element.
     */
    @Override
    public void nextElement() {
      this.keys.add(this.key);
      
      this.key = null;
    }
    
    /**
     * Retrieve the key.
     *
     * @return The key.
     * @see #setKey(String)
     */
    public String getKey() {
      return this.key;
    }

    /**
     * Set the key.
     *
     * @param key The key.
     * @see #getKey()
     */
    public void setKey(String key) {
      if (this.key != null) {
        throw new UnsupportedOperationException("Key already set");
      }
      else if (key == null || key.isEmpty()) {
        throw new IllegalArgumentException("Key cannot be null or empty");
      }
      else if (this.keys.contains(key)) {
        throw new IllegalArgumentException("Duplicate key: " + key);
      }
      
      this.key = key;
    }
  }
  
  /** The JSONP callback pattern. */
  private static final String JSONP_CALLBACK_PATTERN = "^[$A-Za-z_][$0-9A-Za-z_]+$";
  
  /** The format output flag. */
  private final boolean formatOutput;
  
  /** The JSON context. */
  private JsonContext jsonContext;
  
  /**
   * Begin the JSON.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator beginJson() {
    return this.beginJson(null);
  }

  /**
   * Begin the JSON.
   * 
   * @param jsonpCallback The JSONP callback.
   * @return The JSON generator.
   */
  public JsonGenerator beginJson(String jsonpCallback) {
    if (this.jsonContext != null) {
      throw new UnsupportedOperationException("Already begun");
    }
    
    if (jsonpCallback != null) {
      if (!jsonpCallback.matches(JSONP_CALLBACK_PATTERN)) {
        throw new IllegalArgumentException("Invalid JSONP callback: " + jsonpCallback);
      }
      
      this.print(jsonpCallback + "(");
    }
    
    this.jsonContext = new RootJsonContext(jsonpCallback != null);
    
    return this;
  }
  
  /**
   * End the JSON.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator endJson() {
    if (!(this.jsonContext instanceof RootJsonContext)) {
      throw new UnsupportedOperationException("Not in root context");
    }
    RootJsonContext rootJsonContext = (RootJsonContext)this.jsonContext;
    
    this.jsonContext = this.jsonContext.getParentJsonContext();
    
    if (rootJsonContext.isJsonp()) {
      this.print(");");
    }
    
    return this.newline();
  }

  /**
   * Begin an object.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator beginObject() {
    this.beginElement();
    
    this.print("{");
    
    this.jsonContext = new ObjectJsonContext();
    
    return this;
  }

  /**
   * End an object.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator endObject() {
    if (!(this.jsonContext instanceof ObjectJsonContext)) {
      throw new UnsupportedOperationException("Not in object context");
    }
    ObjectJsonContext objectJsonContext = (ObjectJsonContext)this.jsonContext;
    
    this.jsonContext = this.jsonContext.getParentJsonContext();
    
    if (!objectJsonContext.isFirstElement()) {
      this.newline()
          .indent();
    }
    
    this.print("}");
    
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Begin an array.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator beginArray() {
    return this.beginArray(false);
  }

  /**
   * Begin an array.
   * 
   * @param inline The inline flag.
   * @return The JSON generator.
   */
  public JsonGenerator beginArray(boolean inline) {
    this.beginElement();
    
    this.print("[");
    
    this.jsonContext = new ArrayJsonContext(inline);
    
    return this;
  }

  /**
   * End an array.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator endArray() {
    if (!(this.jsonContext instanceof ArrayJsonContext)) {
      throw new UnsupportedOperationException("Not in array context");
    }
    ArrayJsonContext arrayJsonContext = (ArrayJsonContext)this.jsonContext;
    
    this.jsonContext = this.jsonContext.getParentJsonContext();
    
    if (!arrayJsonContext.isFirstElement()) {
      if (arrayJsonContext.isInline()) {
        this.space();
      }
      else  {
        this.newline()
            .indent();
      }
    }
    
    this.print("]");
    
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write a key.
   * 
   * @param key The key.
   * @return The JSON generator.
   */
  public JsonGenerator writeKey(String key) {
    if (!(this.jsonContext instanceof ObjectJsonContext)) {
      throw new UnsupportedOperationException("Not in object context");
    }
    ObjectJsonContext objectJsonContext = (ObjectJsonContext)this.jsonContext;
    
    objectJsonContext.setKey(key);
    
    return this;
  }

  /**
   * Write a NULL value.
   * 
   * @return The JSON generator.
   */
  public JsonGenerator writeNull() {
    this.beginElement();
    
    this.outputNull();
      
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write a boolean.
   *
   * @param bool The boolean.
   * @return The JSON generator.
   */
  public JsonGenerator writeBoolean(boolean bool) {
    this.beginElement();
    
    this.outputBoolean(bool);
    
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write a number.
   *
   * @param number The number.
   * @return The JSON generator.
   */
  public JsonGenerator writeNumber(double number) {
    this.beginElement();
    
    if (!Double.isNaN(number) && !Double.isInfinite(number)) {
      this.outputNumber(number);
    }
    else {
      this.outputNull();
    }
    
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write an integer.
   *
   * @param integer The integer.
   * @return The JSON generator.
   */
  public JsonGenerator writeInteger(int integer) {
    this.beginElement();
    
    this.outputInteger(integer);
      
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write a string.
   *
   * @param string The string.
   * @return The JSON generator.
   */
  public JsonGenerator writeString(String string) {
    this.beginElement();
    
    if (string != null) {
      this.outputString(string);
    }
    else {
      this.outputNull();
    }
      
    this.jsonContext.nextElement();
    
    return this;
  }

  /**
   * Write the given object.
   *
   * @param jsonObject The object.
   * @return The JSON generator.
   */
  public JsonGenerator writeObject(JsonObject jsonObject) {
    if (jsonObject.isArray()) {
      JsonArray jsonArray = jsonObject.cast(JsonArray.class);
      
      this.beginArray();
      
      for (int i = 0; i < jsonArray.getLength(); i++) {
        if (jsonArray.isNullElement(i)) {
          this.writeNull();
        }
        else if (jsonArray.isBooleanElement(i)) {
          this.writeBoolean(jsonArray.getBooleanElement(i));
        }
        else if (jsonArray.isIntegerElement(i)) {
          this.writeInteger(jsonArray.getIntegerElement(i));
        }
        else if (jsonArray.isNumberElement(i)) {
          this.writeNumber(jsonArray.getNumberElement(i));
        }
        else if (jsonArray.isStringElement(i)) {
          this.writeString(jsonArray.getStringElement(i));
        }
        else if (jsonArray.isObjectElement(i)) {
          this.writeObject(jsonArray.getObjectElement(i));
        }
        else {
          assert false : "Unreachable condition";
        }
      }
      
      this.endArray();
    }
    else {
      this.beginObject();
  
      JsonStringArray propertyNames = jsonObject.getPropertyNames();
      for (int i = 0; i < propertyNames.getLength(); i++) {
        String propertyName = propertyNames.get(i);
  
        this.writeKey(propertyName);
        
        if (jsonObject.isNullProperty(propertyName)) {
          this.writeNull();
        }
        else if (jsonObject.isBooleanProperty(propertyName)) {
          this.writeBoolean(jsonObject.getBooleanProperty(propertyName));
        }
        else if (jsonObject.isIntegerProperty(propertyName)) {
          this.writeInteger(jsonObject.getIntegerProperty(propertyName));
        }
        else if (jsonObject.isNumberProperty(propertyName)) {
          this.writeNumber(jsonObject.getNumberProperty(propertyName));
        }
        else if (jsonObject.isStringProperty(propertyName)) {
          this.writeString(jsonObject.getStringProperty(propertyName));
        }
        else if (jsonObject.isObjectProperty(propertyName)) {
          this.writeObject(jsonObject.getObjectProperty(propertyName));
        }
        else {
          assert false : "Unreachable condition";
        }
      }
      
      this.endObject();
    }
    
    return this;
  }

  /**
   * Construct a new JSON Generator Base.
   *
   * @param formatOutput The format output flag.
   */
  protected JsonGenerator(boolean formatOutput) {
    this.formatOutput = formatOutput;
  }
  
  /**
   * Print the given string.
   *
   * @param string The string.
   * @return The JSON generator.
   */
  protected abstract JsonGenerator print(String string);
  
  /**
   * Begin an element.
   * 
   * @return The JSON generator.
   */
  private JsonGenerator beginElement() {
    if (!this.jsonContext.isFirstElement()) {
      this.print(",");
    }
    
    if (this.jsonContext instanceof ArrayJsonContext) {
      ArrayJsonContext arrayJsonContext = (ArrayJsonContext)this.jsonContext;
      
      if (arrayJsonContext.isInline()) {
        this.space();
      }
      else {
        this.newline()
            .indent();
      }
    }
    else if (this.jsonContext instanceof ObjectJsonContext) {
      ObjectJsonContext objectJsonContext = (ObjectJsonContext)jsonContext;
      
      String key = objectJsonContext.getKey();
      if (key == null) {
        throw new UnsupportedOperationException("Key required in object context");
      }
      
      this.newline()
          .indent()
          .outputString(key)
          .space()
          .print(":")
          .space();
    }
    
    return this;
  }
  
  /**
   * Output null.
   * 
   * @return The JSON generator.
   */
  private JsonGenerator outputNull() {
    return this.print("null");
  }
  
  /**
   * Output a boolean.
   *
   * @param bool The boolean.
   * @return The JSON generator.
   */
  private JsonGenerator outputBoolean(boolean bool) {
    return this.print(bool ? "true" : "false");
  }

  /**
   * Output a number.
   *
   * @param number The number.
   * @return The JSON generator.
   */
  private JsonGenerator outputNumber(double number) {
    return this.print(Double.toString(number));
  }
  
  /**
   * Output an integer.
   *
   * @param integer The integer.
   * @return The JSON generator.
   */
  private JsonGenerator outputInteger(int integer) {
    return this.print(Integer.toString(integer));
  }
  
  /**
   * Output a string.
   *
   * @param string The string.
   * @return The JSON generator.
   */
  private JsonGenerator outputString(String string) {
    return this.print("\"")
               .print(string.replaceAll("\\\\", "\\\\\\\\").replaceAll("\\\"", "\\\\\\\""))
               .print("\"");
  }

  /**
   * Output a space.
   * <p>
   * This method will have no effect if the {@link #formatOutput} field is
   * <code>false</code>.
   * 
   * @return The JSON generator.
   */
  private JsonGenerator space() {
    if (this.formatOutput) {
      this.print(" ");
    }
    
    return this;
  }
  
  /**
   * Output an indent to the current nesting level.
   * <p>
   * This method will have no effect if the {@link #formatOutput} field is
   * <code>false</code>.
   * 
   * @return The JSON generator.
   */
  private JsonGenerator indent() {
    if (this.formatOutput) {
      int nestingLevel = this.jsonContext.getNestingLevel();
      
      for (int i = 0; i < nestingLevel; i++) {
        this.print("  ");
      }
    }
    
    return this;
  }
  
  /**
   * Output a new line.
   * <p>
   * This method will have no effect if the {@link #formatOutput} field is
   * <code>false</code>.
   * 
   * @return The JSON generator.
   */
  private JsonGenerator newline() {
    if (this.formatOutput) {
      this.print("\n");
    }
    
    return this;
  }
}
