/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.shared.io;

/**
 * JSON String Builder.
 * <p>
 * Created: 18th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.3
 */
public class JsonStringBuilder extends JsonGenerator {
  /** The string builder. */
  private final StringBuilder stringBuilder;
  
  /**
   * Construct a new JSON String Builder.
   *
   * @param formatOutput The format output flag.
   */
  public JsonStringBuilder(boolean formatOutput) {
    this(new StringBuilder(), formatOutput);
  }
  
  /**
   * Construct a new JSON String Builder.
   *
   * @param stringBuilder The string builder.
   * @param formatOutput The format output flag.
   */
  public JsonStringBuilder(StringBuilder stringBuilder, boolean formatOutput) {
    super(formatOutput);
    
    this.stringBuilder = stringBuilder;
  }
  
  /**
   * Create a string representation of this object.
   *
   * @return The string representation.
   */
  @Override
  public String toString() {
    return this.stringBuilder.toString();
  }
  
  /**
   * Print the given string.
   *
   * @param string The string.
   * @return The JSON generator.
   */
  @Override
  protected JsonGenerator print(String string) {
    this.stringBuilder.append(string);
    
    return this;
  }
}
