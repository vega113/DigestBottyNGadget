/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.server.io;

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.util.Stack;

import org.kjots.jsonObject.rebase.org.json.simple.parser.ContentHandler;
import org.kjots.jsonObject.rebase.org.json.simple.parser.JSONParser;
import org.kjots.jsonObject.rebase.org.json.simple.parser.ParseException;
import org.kjots.jsonObject.shared.JsonArray;
import org.kjots.jsonObject.shared.JsonObject;
import org.kjots.jsonObject.shared.JsonObjectFactory;

/**
 * JSON Reader.
 * <p>
 * Created: 19th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.3
 */
public class JsonReader {
  /**
   * JSON Reader Exception.
   */
  public static class JsonReaderException extends RuntimeException {
    /** Serial Version UID for this {@link Serializable} class. */
    private static final long serialVersionUID = -6065734387669670837L;

    /**
     * Construct a new JSON Reader Exception.
     *
     * @param cause The cause of the exception.
     */
    private JsonReaderException(Throwable cause) {
      super(cause);
    }
  }
  
  /** The input. */
  private final Reader in;
  
  /**
   * Construct a new JSON Reader.
   *
   * @param reader The reader.
   */
  public JsonReader(Reader reader) {
    this.in = reader;
  }
  
  /**
   * Read the JSON object.
   *
   * @throws IOException
   */
  public JsonObject readJsonObject()
    throws IOException {
    final JsonObject[] jsonObjectHolder = new JsonObject[1];

    try {
      new JSONParser().parse(this.in, new ContentHandler() {
        private Stack<JsonObject> stack = new Stack<JsonObject>(); 
        
        private String key;
        
        @Override
        public void startJSON() {
        }
        
        @Override
        public void endJSON() {
        }
        
        @Override
        public boolean startObject() {
          this.startObject(JsonObjectFactory.get().createJsonObject(JsonObject.class));
          
          return true;
        }
        
        @Override
        public boolean endObject() {
          this.stack.pop();
          
          return true;
        }
        
        @Override
        public boolean startObjectEntry(String key) {
          this.key = key;
          
          return true;
        }
        
        @Override
        public boolean endObjectEntry() {
          return true;
        }
        
        @Override
        public boolean startArray()  {
          this.startObject(JsonObjectFactory.get().createJsonArray(JsonArray.class));
          
          return true;
        }
        
        @Override
        public boolean endArray() {
          this.stack.pop();
          
          return true;
        }
        
        @Override
        public boolean primitive(Object value) {
          JsonObject parentJsonObject = this.stack.peek();
          
          if (parentJsonObject.isArray()) {
            JsonArray parentJsonArray = parentJsonObject.cast(JsonArray.class);
            
            if (value == null) {
              parentJsonArray.setObjectElement(parentJsonArray.getLength(), null);
            }
            else if (value instanceof Boolean) {
              Boolean booleanValue = (Boolean)value;
              
              parentJsonArray.setBooleanElement(parentJsonArray.getLength(), booleanValue);
            }
            else if (value instanceof Number) {
              Number numberValue = (Number)value;
              
              double doubleValue = numberValue.doubleValue();
              if (Math.floor(doubleValue) == doubleValue) {
                parentJsonArray.setIntegerElement(parentJsonArray.getLength(), numberValue.intValue());
              }
              else {
                parentJsonArray.setNumberElement(parentJsonArray.getLength(), doubleValue);
              }
            }
            else if (value instanceof String) {
              String stringValue = (String)value;
              
              parentJsonArray.setStringElement(parentJsonArray.getLength(), stringValue);
            }
            else {
              assert false : "Unreachable condition";
            }
          }
          else {
            if (value == null) {
              parentJsonObject.setObjectProperty(this.key, null);
            }
            else if (value instanceof Boolean) {
              Boolean booleanValue = (Boolean)value;
              
              parentJsonObject.setBooleanProperty(this.key, booleanValue);
            }
            else if (value instanceof Number) {
              Number numberValue = (Number)value;
              
              double doubleValue = numberValue.doubleValue();
              if (Math.floor(doubleValue) == doubleValue) {
                parentJsonObject.setIntegerProperty(this.key, numberValue.intValue());
              }
              else {
                parentJsonObject.setNumberProperty(this.key, doubleValue);
              }
            }
            else if (value instanceof String) {
              String stringValue = (String)value;
              
              parentJsonObject.setStringProperty(this.key, stringValue);
            }
            else {
              assert false : "Unreachable condition";
            }
          }
          
          return true;
        }
        
        private void startObject(JsonObject jsonObject) {
          if (!this.stack.empty()) {
            JsonObject parentJsonObject = this.stack.peek();
            
            if (parentJsonObject.isArray()) {
              JsonArray parentJsonArray = parentJsonObject.cast(JsonArray.class);
              
              parentJsonArray.setObjectElement(parentJsonArray.getLength(), jsonObject);
            }
            else {
              parentJsonObject.setObjectProperty(this.key, jsonObject);
            }
          }
          else {
            jsonObjectHolder[0] = jsonObject;
          }
          
          this.stack.push(jsonObject);
        }
      });
    }
    catch (ParseException pe) {
      throw new JsonReaderException(pe);
    }
    
    return jsonObjectHolder[0];
  }
}
