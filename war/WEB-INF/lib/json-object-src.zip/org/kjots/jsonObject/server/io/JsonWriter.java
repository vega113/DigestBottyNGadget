/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.server.io;

import java.io.PrintWriter;
import java.io.Writer;

import org.kjots.jsonObject.shared.io.JsonGenerator;

/**
 * JSON Writer.
 * <p>
 * Created: 18th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.3
 */
public class JsonWriter extends JsonGenerator {
  /** The output. */
  private final PrintWriter out;
  
  /**
   * Construct a new JSON Writer.
   *
   * @param writer The writer.
   * @param formatOutput The format output flag.
   */
  public JsonWriter(Writer writer, boolean formatOutput) {
    super(formatOutput);
    
    this.out = writer instanceof PrintWriter ? (PrintWriter)writer : new PrintWriter(writer);
  }
  
  /**
   * End the JSON.
   * 
   * @return The JSON generator.
   */
  @Override
  public JsonGenerator endJson() {
    super.endJson();
    
    this.out.flush();
    
    return this;
  }
  
  /**
   * Print the given string.
   *
   * @param string The string.
   * @return The JSON generator.
   */
  @Override
  protected JsonGenerator print(String string) {
    this.out.print(string);
    
    return this;
  }
}
