/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.server.js.impl;

import java.lang.reflect.InvocationTargetException;

import javax.script.Invocable;

import com.google.inject.Inject;

import org.kjots.jsonObject.server.js.JsJsonObjectGenerator;
import org.kjots.jsonObject.server.js.JsJsonObjectModule;
import org.kjots.jsonObject.shared.JsonArray;
import org.kjots.jsonObject.shared.JsonBooleanArray;
import org.kjots.jsonObject.shared.JsonBooleanMap;
import org.kjots.jsonObject.shared.JsonIntegerArray;
import org.kjots.jsonObject.shared.JsonIntegerMap;
import org.kjots.jsonObject.shared.JsonNumberArray;
import org.kjots.jsonObject.shared.JsonNumberMap;
import org.kjots.jsonObject.shared.JsonObject;
import org.kjots.jsonObject.shared.JsonObjectArray;
import org.kjots.jsonObject.shared.JsonObjectFactory;
import org.kjots.jsonObject.shared.JsonObjectMap;
import org.kjots.jsonObject.shared.JsonStringArray;
import org.kjots.jsonObject.shared.JsonStringMap;

/**
 * JavaScript JSON Object Instantiator Implementation.
 * <p>
 * Created: 13th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.2
 * @deprecated Use {@link JsonObjectFactory}
 */
@Deprecated
public class JsJsonObjectInstantiatorImpl implements org.kjots.jsonObject.shared.JsonObjectInstantiator<Object> {
  /** The JSON object generator. */
  @Inject
  private JsJsonObjectGenerator jsonObjectGenerator;
  
  /** The JavaScript engine. */
  @Inject
  @JsJsonObjectModule.JsEngine
  private Invocable jsEngine;
  
  /**
   * Create a new JSON object instance with given class using the given
   * underlying JSON object.
   *
   * @param <T> The type of the JSON object.
   * @param jsonObjectClass The class of the JSON object.
   * @param object The underlying JSON object.
   * @return The JSON object.
   * @deprecated Use {@link JsonObjectFactory#createJsonObject(Class, Object)}
   */
  @Override
  @SuppressWarnings("unchecked")
  @Deprecated
  public final <T extends JsonObject> T newInstance(Class<T> jsonObjectClass, Object object) {
    JsJsonObjectImpl jsonObjectImpl = this.createStaticJsonObject(jsonObjectClass, object);
    if (jsonObjectImpl == null) {
      Class<? extends JsJsonObjectImpl> jsonObjectImplClass = this.jsonObjectGenerator.getJsonObjectImplClass(jsonObjectClass);

      try {
        jsonObjectImpl = jsonObjectImplClass.getConstructor(Invocable.class, Object.class).newInstance(this.jsEngine, object);
      }
      catch (NoSuchMethodException nsme) {
        throw new IllegalStateException(nsme);
      }
      catch (IllegalAccessException iae) {
        throw new IllegalStateException(iae);
      }
      catch (InstantiationException ie) {
        throw new IllegalStateException(ie);
      }
      catch (InvocationTargetException ite) {
        Throwable t = ite.getCause();
        
        if (t instanceof RuntimeException) {
          throw (RuntimeException)t;
        }
        else if (t instanceof Error) {
          throw (Error)t;
        }
        else {
          throw new IllegalStateException(t);
        }
      }
    }
    
    return (T)jsonObjectImpl;
  }
  
  /**
   * Create a new JSON object instance with given class using the given
   * underlying JSON object.
   * <p>
   * This method will only create JSON object instances with statically defined
   * implementations.
   *
   * @param jsonObjectClass The class of the JSON object.
   * @param object The underlying JSON object.
   * @return The JSON object.
   */
  private JsJsonObjectImpl createStaticJsonObject(Class<? extends JsonObject> jsonObjectClass, Object object) {
    if (jsonObjectClass.equals(JsonObject.class)) {
      return new JsJsonObjectImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonArray.class)) {
      return new JsJsonArrayImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonBooleanArray.class)) {
      return new JsJsonBooleanArrayImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonNumberArray.class)) {
      return new JsJsonNumberArrayImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonIntegerArray.class)) {
      return new JsJsonIntegerArrayImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonStringArray.class)) {
      return new JsJsonStringArrayImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonObjectArray.class)) {
      return new JsJsonObjectArrayImpl<JsonObject>(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonBooleanMap.class)) {
      return new JsJsonBooleanMapImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonNumberMap.class)) {
      return new JsJsonNumberMapImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonIntegerMap.class)) {
      return new JsJsonIntegerMapImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonStringMap.class)) {
      return new JsJsonStringMapImpl(this.jsEngine, object);
    }
    else if (jsonObjectClass.equals(JsonObjectMap.class)) {
      return new JsJsonObjectMapImpl<JsonObject>(this.jsEngine, object);
    }
    else {
      return null;
    }
  }
}
