/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.server.js.impl;

import com.google.inject.Inject;

import org.kjots.jsonObject.server.js.JsJsonObjectModule;
import org.kjots.jsonObject.shared.JsonArray;
import org.kjots.jsonObject.shared.JsonObject;
import org.kjots.jsonObject.shared.JsonObjectFactory;

/**
 * JavaScript JSON Object Utility Implementation.
 * <p>
 * Created: 13th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.2
 * @deprecated Use {@link JsonObjectFactory}
 */
@Deprecated
public class JsJsonObjectUtilImpl extends org.kjots.jsonObject.shared.JsonObjectUtil {
  /** The JSON object instantiator. */
  @Inject
  private org.kjots.jsonObject.shared.JsonObjectInstantiator<Object> jsonObjectInstantiator;
  
  /** The JavaScript object provider. */
  @Inject
  private JsJsonObjectModule.JsObjectProvider jsObjectProvider;
  
  /** The JavaScript array provider. */
  @Inject
  private JsJsonObjectModule.JsArrayProvider jsArrayProvider;
  
  /**
   * Create a new JSON object.
   *
   * @param <T> The type of the JSON object.
   * @param jsonObjectClass The class of the JSON object.
   * @return The JSON object.
   * @deprecated Use {@link JsonObjectFactory#createJsonObject(Class)}
   */
  @Override
  @Deprecated
  public final <T extends JsonObject> T createJsonObject(Class<T> jsonObjectClass) {
    return this.jsonObjectInstantiator.newInstance(jsonObjectClass, this.jsObjectProvider.get());
  }
  
  /**
   * Create a new JSON array.
   *
   * @param <T> The type of the JSON array.
   * @param jsonObjectClass The class of the JSON array.
   * @return The JSON array.
   * @deprecated Use {@link JsonObjectFactory#createJsonArray(Class)}
   */
  @Override
  @Deprecated
  public final <T extends JsonArray> T createJsonArray(Class<T> jsonObjectClass) {
    return this.jsonObjectInstantiator.newInstance(jsonObjectClass, this.jsArrayProvider.get());
  }
}
