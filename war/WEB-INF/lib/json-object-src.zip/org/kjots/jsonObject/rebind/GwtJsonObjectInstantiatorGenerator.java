/* 
 * Copyright © 2009 Karl J. Ots <kjots@kjots.org>
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kjots.jsonObject.rebind;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.JsArray;
import com.google.gwt.core.client.JsArrayBoolean;
import com.google.gwt.core.client.JsArrayInteger;
import com.google.gwt.core.client.JsArrayNumber;
import com.google.gwt.core.client.JsArrayString;
import com.google.gwt.core.ext.Generator;
import com.google.gwt.core.ext.GeneratorContext;
import com.google.gwt.core.ext.TreeLogger;
import com.google.gwt.core.ext.UnableToCompleteException;
import com.google.gwt.core.ext.typeinfo.JClassType;
import com.google.gwt.core.ext.typeinfo.NotFoundException;
import com.google.gwt.core.ext.typeinfo.TypeOracle;
import com.google.gwt.user.rebind.ClassSourceFileComposerFactory;
import com.google.gwt.user.rebind.SourceWriter;

import org.kjots.jsonObject.client.impl.GwtJsonArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonBooleanArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonBooleanMapImpl;
import org.kjots.jsonObject.client.impl.GwtJsonIntegerArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonIntegerMapImpl;
import org.kjots.jsonObject.client.impl.GwtJsonNumberArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonNumberMapImpl;
import org.kjots.jsonObject.client.impl.GwtJsonObjectArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonObjectImpl;
import org.kjots.jsonObject.client.impl.GwtJsonObjectMapImpl;
import org.kjots.jsonObject.client.impl.GwtJsonStringArrayImpl;
import org.kjots.jsonObject.client.impl.GwtJsonStringMapImpl;
import org.kjots.jsonObject.shared.JsonArray;
import org.kjots.jsonObject.shared.JsonBooleanArray;
import org.kjots.jsonObject.shared.JsonBooleanMap;
import org.kjots.jsonObject.shared.JsonIntegerArray;
import org.kjots.jsonObject.shared.JsonIntegerMap;
import org.kjots.jsonObject.shared.JsonNumberArray;
import org.kjots.jsonObject.shared.JsonNumberMap;
import org.kjots.jsonObject.shared.JsonObject;
import org.kjots.jsonObject.shared.JsonObjectArray;
import org.kjots.jsonObject.shared.JsonObjectFactory;
import org.kjots.jsonObject.shared.JsonObjectMap;
import org.kjots.jsonObject.shared.JsonStringArray;
import org.kjots.jsonObject.shared.JsonStringMap;

/**
 * GWT JSON Object Instantiator Generator.
 * <p>
 * Created: 8th December 2009.
 *
 * @author <a href="mailto:kjots@kjots.org">Karl J. Ots &lt;kjots@kjots.org&gt;</a>
 * @since 0.1
 * @deprecated Use {@link JsonObjectFactory}
 */
@Deprecated
public class GwtJsonObjectInstantiatorGenerator extends Generator {
  /**
   * Generate the code for the type with the given name.
   *
   * @param logger The logger.
   * @param context The context.
   * @param typeName The type name.
   * @return The name of the generated  class.
   * @throws UnableToCompleteException
   */
  @Override
  public String generate(TreeLogger logger, GeneratorContext context, String typeName)
    throws UnableToCompleteException {
    TypeOracle typeOracle = context.getTypeOracle();
    
    JClassType typeClassType = typeOracle.findType(typeName);
    if (!typeClassType.getQualifiedBinaryName().equals(org.kjots.jsonObject.shared.JsonObjectInstantiator.class.getName())) {
      logger.log(TreeLogger.ERROR, "This generator only supports " + org.kjots.jsonObject.shared.JsonObjectInstantiator.class.getName(), null);
      
      throw new UnableToCompleteException();
    }
    
    String implPackage =  typeOracle.findType(GwtJsonObjectImpl.class.getName()).getPackage().getName();
    String implClassName = "Gwt" + typeClassType.getName() + "Impl";
    
    PrintWriter printWriter = context.tryCreate(logger, implPackage, implClassName);
    if (printWriter != null) {
      ClassSourceFileComposerFactory composerFactory = new ClassSourceFileComposerFactory(implPackage, implClassName);
      
      composerFactory.addImplementedInterface(typeClassType.getQualifiedSourceName() + "<" + JavaScriptObject.class.getName() + ">");
      
      SourceWriter sourceWriter = composerFactory.createSourceWriter(context, printWriter);
      
      this.writeInstantiators(logger, context, sourceWriter);
      
      sourceWriter.println();
      sourceWriter.println("@Override");
      sourceWriter.println("@SuppressWarnings(\"unchecked\")");
      sourceWriter.println("public <T extends " + JsonObject.class.getName() + "> T newInstance(" + Class.class.getName() + "<T> jsonObjectClass, " + JavaScriptObject.class.getName() + " object) {");
      sourceWriter.indent();
      sourceWriter.println("Instantiator<T> instantiator = (Instantiator<T>)instantiators.get(jsonObjectClass);");
      sourceWriter.println();
      sourceWriter.println("return instantiator != null ? instantiator.newInstance(object) : null;");
      sourceWriter.outdent();
      sourceWriter.println("}");
      
      sourceWriter.commit(logger);
    }

    return implPackage + "." + implClassName;
  }
  
  /**
   * Write the instantiators.
   *
   * @param logger The logger.
   * @param context The context.
   * @param sourceWriter The source writer.
   * @throws UnableToCompleteException 
   */
  private void writeInstantiators(TreeLogger logger, GeneratorContext context, SourceWriter sourceWriter)
    throws UnableToCompleteException {
    sourceWriter.println("private static interface Instantiator<T extends " + JsonObject.class.getName() + "> {");
    sourceWriter.indent();
    sourceWriter.println("public T newInstance(" + JavaScriptObject.class.getName() + " jsObject);");
    sourceWriter.outdent();
    sourceWriter.println("}");
    sourceWriter.println();
    
    sourceWriter.println("private static final " + Map.class.getName() + "<Class<? extends " + JsonObject.class.getName() + ">, Instantiator<?>> instantiators = new " + HashMap.class.getName() + "<Class<? extends " + JsonObject.class.getName() + ">, Instantiator<?>>();");
    sourceWriter.println("static {");
    sourceWriter.indent();
    
    writeInstantiator(sourceWriter, JsonObject.class.getName(), GwtJsonObjectImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonArray.class.getName(), GwtJsonArrayImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonBooleanArray.class.getName(), GwtJsonBooleanArrayImpl.class.getName(), JsArrayBoolean.class.getName());
    writeInstantiator(sourceWriter, JsonNumberArray.class.getName(), GwtJsonNumberArrayImpl.class.getName(), JsArrayNumber.class.getName());
    writeInstantiator(sourceWriter, JsonIntegerArray.class.getName(), GwtJsonIntegerArrayImpl.class.getName(), JsArrayInteger.class.getName());
    writeInstantiator(sourceWriter, JsonStringArray.class.getName(), GwtJsonStringArrayImpl.class.getName(), JsArrayString.class.getName());
    writeInstantiator(sourceWriter, JsonObjectArray.class.getName(), GwtJsonObjectArrayImpl.class.getName(), JsArray.class.getName() + "<?>");
    writeInstantiator(sourceWriter, JsonBooleanMap.class.getName(), GwtJsonBooleanMapImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonNumberMap.class.getName(), GwtJsonNumberMapImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonIntegerMap.class.getName(), GwtJsonIntegerMapImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonStringMap.class.getName(), GwtJsonStringMapImpl.class.getName(), null);
    writeInstantiator(sourceWriter, JsonObjectMap.class.getName(), GwtJsonObjectMapImpl.class.getName(), null);
    
    for (Map.Entry<String, String> entry : this.getJsonObjectImplClasses(logger, context).entrySet()) {
      writeInstantiator(sourceWriter, entry.getKey(), entry.getValue(), null);
    }
    
    sourceWriter.outdent();
    sourceWriter.println("}");
  }
  
  /**
   * Write an instantiator for the given JSON object and implementation types.
   *
   * @param sourceWriter The source writer.
   * @param jsonObjectTypeName The name of the JSON object type.
   * @param jsonObjectImplTypeName The name of the JSON object implementation type.
   * @param jsObjectTypeName The name of the JavaScript object type.
   */
  private void writeInstantiator(SourceWriter sourceWriter, String jsonObjectTypeName, String jsonObjectImplTypeName, String jsObjectTypeName) {
    sourceWriter.println("instantiators.put(" + jsonObjectTypeName + ".class, new Instantiator<" + jsonObjectTypeName + ">() {");
    sourceWriter.indent();
    sourceWriter.println("public final " + jsonObjectTypeName + " newInstance(" + JavaScriptObject.class.getName() + " jsObject) {");
    sourceWriter.indent();
    if (jsObjectTypeName != null) {
      sourceWriter.println("return new " + jsonObjectImplTypeName + "((" + jsObjectTypeName + ")jsObject.cast());");
    }
    else {
      sourceWriter.println("return new " + jsonObjectImplTypeName + "(jsObject);");
    }
    sourceWriter.outdent();
    sourceWriter.println("}");
    sourceWriter.outdent();
    sourceWriter.println("});");
  }
  
  /**
   * Retrieve the JSON object implementation classes.
   *
   * @param logger The logger.
   * @param context The context.
   * @return The JSON object implementation classes.
   * @throws NotFoundException 
   */
  private Map<String, String> getJsonObjectImplClasses(TreeLogger logger, GeneratorContext context)
    throws UnableToCompleteException {
    Map<String, String> jsonObjectImplClasses = new HashMap<String, String>();
    
    TypeOracle typeOracle = context.getTypeOracle();
    JClassType jsonObjectType = typeOracle.findType(JsonObject.class.getName());
    
    for (JClassType type : typeOracle.getTypes()) {
      if (type.isInterface() != null && type.isAssignableTo(jsonObjectType) && !(type.getPackage().equals(jsonObjectType.getPackage()) && type.getEnclosingType() == null)) {
        String typeName = type.getQualifiedSourceName();
        
        String implTypeName = typeName + "Impl";
        if (typeOracle.findType(implTypeName) == null) {
          implTypeName = new GwtJsonObjectGenerator().generate(logger, context, typeName);
        }
        
        jsonObjectImplClasses.put(typeName, implTypeName);
      }
    }
    
    return jsonObjectImplClasses;
  }
}
